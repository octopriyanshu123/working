#include <ros/ros.h>
#include <sensor_msgs/Joy.h>
#include <geometry_msgs/Twist.h>
#include <std_srvs/Empty.h>

class JoyToCmdVel
{
public:
    JoyToCmdVel()
    {
        cmd_vel_pub_ = nh_.advertise<geometry_msgs::Twist>("/turtle1/cmd_vel", 10);
        joy_sub_ = nh_.subscribe("/joy", 10, &JoyToCmdVel::joyCallback, this);
        pub_joy_timer_ = nh_.createTimer(ros::Duration(0.1), &JoyToCmdVel::pub_joy_timer_callback, this, false, false); 

        // Initialize service clients for starting and stopping the turtle
        start_to_gole_ = nh_.serviceClient<std_srvs::Empty>("/start_to_gole");
        stop_to_gole_ = nh_.serviceClient<std_srvs::Empty>("/stop_to_gole");

        // Initialize turtle position control
        joy_axes_ = sensor_msgs::Joy();
    }

    void joyCallback(const sensor_msgs::Joy::ConstPtr& joy)
    {
        joy_axes_ = *joy;
        if(joy->buttons[6]) {  
            startTimer();
            callStartService();  // Trigger the start service
        }
        if(joy->buttons[7]) {  // Button 7 to stop the timer (stop the turtle movement)
            stopTimer();
            callStopService();   // Trigger the stop service
        }
        if(joy->buttons[4]) {  // Button 6 to start the timer (start the turtle movement)
            startTimer();
        }
        if(joy->buttons[5]) {  // Button 7 to stop the timer (stop the turtle movement)
            stopTimer();
        }
    }

    void pub_joy_timer_callback(const ros::TimerEvent &event)
    {
        try
        {
            geometry_msgs::Twist cmd_vel;
            cmd_vel.linear.x = (joy_axes_.axes[1])*0.5;   // Forward/backward control (typically axis 1 for joystick)
            cmd_vel.angular.z = (joy_axes_.axes[2])*0.5;  // Rotation control (typically axis 2 for joystick)
            cmd_vel_pub_.publish(cmd_vel);           // Publish the cmd_vel message         
        }
        catch(const std::exception& e)
        {
            std::cerr << e.what() << '\n';
        }    
    }

    void startTimer()
    {
        // Start the timer (if not already started)
        if (!pub_joy_timer_.hasStarted()) {
            ROS_INFO("Starting the timer...");
            pub_joy_timer_.start();
        }
    }

    void stopTimer()
    {
        // Stop the timer (if started)
        if (pub_joy_timer_.hasStarted()) {
            ROS_INFO("Stopping the timer...");
            pub_joy_timer_.stop();
        }
    }

    void callStartService()
    {
        std_srvs::Empty srv;
        if (start_to_gole_.call(srv)) {
            ROS_INFO("Start service successfully called!");
        } else {
            ROS_ERROR("Failed to call start service.");
        }
    }

    void callStopService()
    {
        std_srvs::Empty srv;
        if (stop_to_gole_.call(srv)) {
            ROS_INFO("Stop service successfully called!");
        } else {
            ROS_ERROR("Failed to call stop service.");
        }
    }

private:
    ros::NodeHandle nh_;
    ros::Publisher cmd_vel_pub_;
    ros::Subscriber joy_sub_;
    ros::Timer pub_joy_timer_;
    ros::ServiceClient start_to_gole_;
    ros::ServiceClient stop_to_gole_;

    sensor_msgs::Joy joy_axes_;
};

int main(int argc, char** argv)
{
    ros::init(argc, argv, "joy_to_cmd_vel");
    JoyToCmdVel joy_to_cmd_vel;
    ros::spin();
    return 0;
}
