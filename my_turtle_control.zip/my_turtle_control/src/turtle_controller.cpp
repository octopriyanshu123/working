#include <ros/ros.h>
#include <turtlesim/TeleportAbsolute.h>
#include <turtlesim/SetPen.h>
#include <turtlesim/Pose.h>
#include <cstdlib> 
#include <std_srvs/Empty.h>
#include <cmath>  
#include <geometry_msgs/Twist.h>  

template <typename T>
class PIDController {
public:
    PIDController(T Kp, T Ki, T Kd)
        : Kp_(Kp), Ki_(Ki), Kd_(Kd), prev_error_(0), integral_(0) {}

    // Calculate the control signal based on the error
    T compute(T error) {
        // Integral of the error
        integral_ += error;
        
        // Derivative of the error
        T derivative = error - prev_error_;
        
        // Proportional term
        T output = Kp_ * error + Ki_ * integral_ + Kd_ * derivative;

        // Update previous error
        prev_error_ = error;

        return output;
    }

private:
    T Kp_;  // Proportional constant
    T Ki_;  // Integral constant
    T Kd_;  // Derivative constant

    T prev_error_;  // Previous error for derivative term
    T integral_;    // Integral of the error
};



class TurtleController {
public:
    TurtleController(ros::NodeHandle nh) : nh_(nh) ,
    linear_pid_(1.0f, 0.0f, 0.1f),  // Initialize PID for linear velocity with float
    angular_pid_(2.0f, 0.0f, 0.1f) 
    {
        teleport_client_ = nh_.serviceClient<turtlesim::TeleportAbsolute>("turtle1/teleport_absolute");
        set_pen_client_ = nh_.serviceClient<turtlesim::SetPen>("turtle1/set_pen");
        gole_pose_subscriber_ = nh_.subscribe("turtlesim/GolePose", 10, &TurtleController::goleposeCallback, this);
        move_to_gole_timer_ = nh_.createTimer(ros::Duration(0.1), &TurtleController::move_to_gole_timer_callback, this, false, false);
        start_timer_service_ = nh_.advertiseService("start_to_gole", &TurtleController::startTimerService, this);
        stop_timer_service_ = nh_.advertiseService("stop_to_gole", &TurtleController::stopTimerService, this);
        cmd_val_pub_ = nh_.advertise<geometry_msgs::Twist>("turtle1/cmd_vel", 10);  // Initialize the publisher


        turtlesim::SetPen pen_service;
        pen_service.request.r = 255;
        pen_service.request.g = 0;
        pen_service.request.b = 0;
        pen_service.request.width = 3;
        pen_service.request.off = false;
        set_pen_client_.call(pen_service);

        teleportTurtle(5.0, 5.0, 0.0);
        pose_subscriber_ = nh_.subscribe("turtle1/pose", 10, &TurtleController::poseCallback, this);
        turtleCurrPose.x = 0.0;
        turtleCurrPose.y = 0.0;
        turtleCurrPose.theta = 0.0;

        turtleGolePose.x = 0.0;
        turtleGolePose.y = 0.0;
        turtleGolePose.theta = 0.0;

        tolerance = 0.5;

        // Initialize the PID controllers for linear and angular velocity
        PIDController<float> linear_pid(1.0, 0.1, 0.01);  // Example with float
        PIDController<float> angular_pid(1.0, 0.1, 0.01);  // Example with float
        
    }

    void teleportTurtle(double x, double y, double theta) {
        turtlesim::TeleportAbsolute teleport_service;
        teleport_service.request.x = x;
        teleport_service.request.y = y;
        teleport_service.request.theta = theta;
        teleport_client_.call(teleport_service);
    }

    void poseCallback(const turtlesim::Pose::ConstPtr& msg) {
        turtleCurrPose.x = msg->x;
        turtleCurrPose.y = msg->y;
        turtleCurrPose.theta = msg->theta;
    }

    void goleposeCallback(const turtlesim::Pose::ConstPtr& msg) {
        turtleGolePose.x = msg->x;
        turtleGolePose.y = msg->y;
        turtleGolePose.theta = msg->theta;
        ROS_INFO("Turtle Goal position - x: %f, y: %f, theta: %f", turtleGolePose.x, turtleGolePose.y, turtleGolePose.theta);
    }

    void move_to_gole_timer_callback(const ros::TimerEvent& event) {
        // Calculate the Euclidean distance between current position and goal position
        float distance_to_goal = std::sqrt(std::pow(turtleGolePose.x - turtleCurrPose.x, 2) +
                                           std::pow(turtleGolePose.y - turtleCurrPose.y, 2));
        
        // Calculate the angle to the goal
        float angle_to_goal = std::atan2(turtleGolePose.y - turtleCurrPose.y,
                                          turtleGolePose.x - turtleCurrPose.x);
        
        // Calculate the angle error (difference between the desired angle and current orientation)
        float angle_error = normalizeAngle(angle_to_goal - turtleCurrPose.theta);  // Normalize the angle error
  
        // Check if the turtle is not at the goal
        if (distance_to_goal > tolerance || std::abs(angle_error) > tolerance) {
            ROS_INFO("Turtle is not in the goal position. Distance: %.2f, Angle to goal: %.2f, Angle error: %.2f", 
                     distance_to_goal, angle_to_goal, angle_error);

            // Use PID controller to calculate the velocities
            new_vel.linear.x = linear_pid_.compute(distance_to_goal); // PID control for linear velocity
            new_vel.angular.z = angular_pid_.compute(angle_error);   // PID control for angular velocity

            // Publish the velocity command
            cmd_val_pub_.publish(new_vel);
        } else {
            ROS_INFO("Turtle has reached the goal position");

            // Stop the turtle when goal is reached
            new_vel.linear.x = 0.0;
            new_vel.angular.z = 0.0;
            cmd_val_pub_.publish(new_vel);
        }
    }

    bool startTimerService(std_srvs::Empty::Request &req, std_srvs::Empty::Response &res) {
        if (!move_to_gole_timer_.hasStarted()) {
            ROS_INFO("Starting the timer...");
            move_to_gole_timer_.start();
            return true;
        }
        ROS_WARN("Timer already started");
        return false;
    }

    bool stopTimerService(std_srvs::Empty::Request &req, std_srvs::Empty::Response &res) {
        if (move_to_gole_timer_.hasStarted()) {
            ROS_INFO("Stopping the timer...");
            move_to_gole_timer_.stop();
            return true;
        }
        ROS_WARN("Timer is not running");
        return false;
    }
    float normalizeAngle(float angle) {
      while (angle > M_PI) {
          angle -= 2 * M_PI;  // Subtract 2π if the angle exceeds π
      }
      while (angle < -M_PI) {
          angle += 2 * M_PI;  // Add 2π if the angle is less than -π
      }
      return angle;
  }

private:
    ros::NodeHandle nh_;
    ros::ServiceClient teleport_client_;
    ros::ServiceClient set_pen_client_;
    ros::Subscriber pose_subscriber_;
    ros::Subscriber gole_pose_subscriber_;
    ros::Timer move_to_gole_timer_;
    ros::Publisher cmd_val_pub_;

    ros::ServiceServer start_timer_service_;
    ros::ServiceServer stop_timer_service_;

    PIDController<float> linear_pid_;  // Use float type for linear PID
    PIDController<float> angular_pid_; // Use float type for angular PID

    struct Pose {
        float x;
        float y;
        float theta;
    };

    Pose turtleCurrPose; 
    Pose turtleGolePose; 
    geometry_msgs::Twist new_vel;

    float tolerance;
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "turtle_controller");
    ros::NodeHandle nh;

    TurtleController controller(nh);
    ros::spin();

    return 0;
}
