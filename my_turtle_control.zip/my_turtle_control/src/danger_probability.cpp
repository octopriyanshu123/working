#include <ros/ros.h>
#include <std_msgs/Float32MultiArray.h>  // Include for the Float32MultiArray message type
#include <cstdlib>  // For random number generation
#include <ctime>    // For seeding the random number generator

class DangerProbabilityPublisher {
public:
    // Constructor that initializes the ROS node and publisher
    DangerProbabilityPublisher(ros::NodeHandle& nh) {
        // Initialize the publisher for the "danger_probabilities" topic
        pub_ = nh.advertise<std_msgs::Float32MultiArray>("danger_probabilities", 10);
        
        // Create a timer that calls the publishDangerProbabilities function every 1 second
        timer_ = nh.createTimer(ros::Duration(10.0), &DangerProbabilityPublisher::publishDangerProbabilities, this);
        
        // Seed the random number generator to ensure different values each time
        srand(static_cast<unsigned int>(time(0)));
    }

private:
    // Timer callback that publishes random danger probabilities
    void publishDangerProbabilities(const ros::TimerEvent&) {
        // Create a message to hold the danger probabilities
        std_msgs::Float32MultiArray msg;
        
        // Example array of random danger probabilities (4 values)
        float danger_probabilities[4];
        
        // Generate random danger probabilities between 0 and 1
        for (int i = 0; i < 4; ++i) {
            danger_probabilities[i] = generateRandomFloat(0.0f, 1.0f);  // Random value between 0 and 1
        }
        
        // Fill the message with the array
        msg.data = {danger_probabilities[0], danger_probabilities[1], danger_probabilities[2], danger_probabilities[3]};
        
        // Publish the message to the "danger_probabilities" topic
        pub_.publish(msg);
    }

    // Function to generate a random float in the range [min, max]
    float generateRandomFloat(float min, float max) {
        return min + static_cast<float>(rand()) / (static_cast<float>(RAND_MAX) / (max - min));
    }

    ros::Publisher pub_;  // Publisher for the "danger_probabilities" topic
    ros::Timer timer_;    // Timer for periodic callback execution
};

int main(int argc, char** argv) {
    // Initialize the ROS node
    ros::init(argc, argv, "danger_probability_publisher");
    ros::NodeHandle nh;
    
    // Create the DangerProbabilityPublisher object
    DangerProbabilityPublisher publisher(nh);
    
    // Spin and wait for the timer callback to execute
    ros::spin();
    
    return 0;
}
