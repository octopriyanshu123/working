- mmap allocating memory (syscall for malloc)
- reading files
- IPC Inter Process Communication
- precise control over memory protection


stst(2)

