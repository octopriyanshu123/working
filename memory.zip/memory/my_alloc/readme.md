brk()
sbrk()
two syscall to ask for the memory from the kernal
