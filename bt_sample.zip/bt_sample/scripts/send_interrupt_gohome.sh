#!/bin/sh

rostopic pub /interrupt_event std_msgs/String "gohome"
